export function nowMS() {
  return new Date().getTime();
}
