export enum Network {
  MAINNET = "mainnet-beta",
  DEVNET = "devnet",
}
